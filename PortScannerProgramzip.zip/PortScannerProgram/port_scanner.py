import socket
import csv
from datetime import datetime

# 1. Multiple Target Assets (Simulating Subnet Scan)
TARGETS = [
    {"ip": "127.0.0.1", "hostname": "Local-Workstation"},
    {"ip": "192.168.1.1", "hostname": "Core-Router"},
    {"ip": "192.168.1.50", "hostname": "DB-Server-Internal"},
    {"ip": "192.168.1.100", "hostname": "Web-App-Staging"}
]

# Ports to inspect
PORTS_TO_SCAN = [21, 22, 23, 25, 53, 80, 110, 135, 139, 143, 443, 445, 1433, 3306, 3389, 8080]

# Expanded Risk & Remediation Dictionary
PORT_INFO = {
    21: ("FTP", "High", "Enforce SFTP/FTPS; disable plain text FTP"),
    22: ("SSH", "Low", "Ensure key-based auth and strong encryption"),
    23: ("Telnet", "Critical", "Disable Telnet immediately; migrate to SSH"),
    25: ("SMTP", "Medium", "Configure TLS encryption and authentication"),
    53: ("DNS", "Low", "Restrict zone transfers and recursive lookup"),
    80: ("HTTP", "Medium", "Enforce HTTPS redirect (Port 443)"),
    110: ("POP3", "High", "Disable unencrypted POP3; use POP3S"),
    135: ("MS-RPC", "Medium", "Restrict access via firewall to internal subnets"),
    139: ("NetBIOS", "High", "Disable NetBIOS over TCP/IP if not required"),
    143: ("IMAP", "Medium", "Migrate traffic to IMAPS (Port 993)"),
    443: ("HTTPS", "Low", "Verify valid SSL/TLS certificate configuration"),
    445: ("SMB", "Critical", "Block external SMB; patch against EternalBlue/WannaCry"),
    1433: ("MSSQL", "High", "Restrict DB access to trusted application servers"),
    3306: ("MySQL", "High", "Bind to localhost; disable public DB access"),
    3389: ("RDP", "Critical", "Enforce Network Level Auth (NLA) & VPN gateway"),
    8080: ("HTTP-Proxy", "Medium", "Restrict management dashboard exposure")
}

# 2. Prepare Export
filename = f"scan_results_{datetime.now().strftime('%Y%m%d')}.csv"

with open(filename, mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(["Target IP", "Hostname", "Port", "Service", "Risk Level", "Remediation", "Timestamp"])

    print("Starting Multi-Target Security Scan...\n")

    for target in TARGETS:
        ip = target["ip"]
        hostname = target["hostname"]
        print(f"[*] Scanning {hostname} ({ip})...")

        for port in PORTS_TO_SCAN:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(0.3)
            result = sock.connect_ex((ip, port))

            if result == 0:
                service, risk, remediation = PORT_INFO.get(
                    port, ("Unknown Service", "Info", "Review port requirement")
                )
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                writer.writerow([ip, hostname, port, service, risk, remediation, timestamp])
                print(f"    [!] OPEN: Port {port} ({service}) - Risk: {risk}")

            sock.close()

print(f"\nScan complete. Output saved to {filename}")